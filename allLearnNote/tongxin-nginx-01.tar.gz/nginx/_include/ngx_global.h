﻿
#ifndef __NGX_GBLDEF_H__
#define __NGX_GBLDEF_H__


// 配置文件结构的定义
typedef struct
{
	char ItemName[50];
	char ItemContent[500];
}CConfItem,*LPCConfItem;   //LPCConfItem 是个结构指针 CConfItem 是结构类型

#endif