﻿#ifndef __NGX_CONF_H__
#define __NGX_CONF_H__

#include <vector>
#include <ngx_global.h>

//读取配置文件相关的类,是一个单例类
class CConfig
{
private:
	CConfig();
	static CConfig *m_instance;

public:
	~CConfig();
	static CConfig* GetInstance() {
		if(m_instance == NULL) {
			m_instance = new CConfig();
			//定义一个内部类用于自动释放对象
			static CGarhuishou cl; 
		}
		return m_instance;
	}
	//定义一个嵌套列，专门为CConfig服务，还用于释放 m_instance
	class CGarhuishou {
	public:
		~CGarhuishou() {
			if( CConfig::m_instance ) {
				delete m_instance;
				CConfig:m_instance = NULL;
			}
		}
	};

// --------------------- 下面实现一些功能函数 --------------------------
public:
	// 加载配置文件函数
	bool Load(const char * pconfName);  // 传入的是配置文件的文件名
	//获取配置文件信息函数
	const char *GetString(const char *p_itemname);  //获取字符类型
	int GetIntDefault(const char *p_itemname,const int def);	//数字类型配置信息
	//如果返回def 就是没找到

	//存储配置文件
	std::vector<LPCConfItem> m_ConfigItemList;

};

#endif