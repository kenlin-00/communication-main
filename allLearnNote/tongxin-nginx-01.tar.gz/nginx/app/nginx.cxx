﻿
// 主函数入口
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "ngx_c_conf.h"

using namespace std;

int main(int argc,char *const *argv) {

    //创建一个读取配置文件的类
    CConfig *p_config = CConfig::GetInstance();
    //  CConfig *p_config1 = CConfig::GetInstance();

    //使用C++的方式打印对象的地址
    // cout << "p_config的地址是："  << static_cast<void *>(p_config) << endl;
    // cout << "p_config1的地址是："  << static_cast<void *>(p_config1) << endl;
    // //使用C语言的方式打印对象的地址
    // printf("p_config的地址是：%p\n",p_config);
    // printf("p_config1的地址是：%p\n",p_config1);
    //上面输出的地址都是一样的，说明单例模式没问题

    //把配置文件读出来
    if(p_config->Load("nginx.conf") == false) //把配置文件内容载入到内存
    {
        printf("配置文件载入失败，退出!\n");
        exit(1);
    }
    cout << "========> 打开配置文件成功 <============" << endl;


    //读取配置文件信息测试
    //获取端口
    int port = p_config->GetIntDefault("ListenPort",0); //0是缺省值 返回 0就是没获取到
    cout << "ListenPort = " << port << endl;

    //获取 DBInfo
    const char *pDBInfo = p_config->GetString("DBInfo");
    if (pDBInfo != NULL)
    {
        cout << "DBInfo =  " << pDBInfo << endl;
    }
    

    

    return 0;
}