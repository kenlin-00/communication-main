﻿#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "ngx_global.h"  

void ngx_init_setproctitle()
{
	int i;
	//统计环境变量所占用的内存
	for(i = 0;environ[i] != NULL;++i) {
		g_environlen += strlen(environ[i]) + 1; //需要算上 结尾的“\n"
	}

	//分配一块新的内存来保存环境变量，在nginx.cxx释放
	gp_envmem  = new char[g_environlen];
	//初始化
	memset(gp_envmem,0,g_environlen);

	//把原来的内存帮到这里来
	char *ptmp = gp_envmem;
	for(int i = 0;environ[i] != NULL;++i) {
		size_t size = strlen(environ[i]+1);
		strcpy(ptmp,environ[i]);
		environ[i] = ptmp;
		ptmp += size; //指针后移size大小，也就是一个环境变量的大小
	}
	return;
}

//设置可执行程序标题
//首先计算要设置的标题的长度，算出argv的长度和环境变量的长度，
// 如果设置的标题比这个长度还大，那就不要替换了
// 还要将剩余的原argv以及environ所占的内存全部清0
void ngx_setproctitle(const char *title) 
{
	//计算标题的长度
	ssize_t ititlelen = strlen(title);

	// 计算总的原始的argv那块内存的总长度【包括各种参数】
	size_t e_environlen = 0;
	//计算原始命令的长度
	for(int i=0;g_os_argv[i];++i){
		e_environlen += strlen(g_os_argv[i]) +1;
	}

	//环境变量和输入的argv长度
	size_t esy = e_environlen  + g_environlen;
	if( esy <= ititlelen ) {
		return;
	}
	g_os_argv[1] = NULL;

	char *ptmp = g_os_argv[0];
	strcpy(ptmp,title);
	ptmp += ititlelen; //跳过标题

	size_t cha = esy - ititlelen;
	memset(ptmp,0,cha);
	return;

}