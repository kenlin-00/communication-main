﻿
// 主函数入口
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "ngx_c_conf.h"
#include "ngx_global.h"
#include "ngx_func.h"

using namespace std;

// 和设置标题相关的全局变量
char **g_os_argv;       // 输入的原始命令
char *gp_envmem = NULL;      //指向自己分配的env环境变量的内存
int  g_environlen = 0;       //环境变量所占内存大小

int main(int argc,char *const *argv) {

    g_os_argv = (char**) argv;  //先保存原始的命令

    //环境变量移动到新的内存空间
    ngx_init_setproctitle();

    //创建一个读取配置文件的类
    CConfig *p_config = CConfig::GetInstance();
    //  CConfig *p_config1 = CConfig::GetInstance();

    //使用C++的方式打印对象的地址
    // cout << "p_config的地址是："  << static_cast<void *>(p_config) << endl;
    // cout << "p_config1的地址是："  << static_cast<void *>(p_config1) << endl;
    // //使用C语言的方式打印对象的地址
    // printf("p_config的地址是：%p\n",p_config);
    // printf("p_config1的地址是：%p\n",p_config1);
    //上面输出的地址都是一样的，说明单例模式没问题

    //把配置文件读出来
    if(p_config->Load("nginx.conf") == false) //把配置文件内容载入到内存
    {
        printf("配置文件载入失败，退出!\n");
        exit(1);
    }
    cout << "========> 打开配置文件成功 <============" << endl;


    //读取配置文件信息测试
    //获取端口
    int port = p_config->GetIntDefault("ListenPort",0); //0是缺省值 返回 0就是没获取到
    cout << "ListenPort = " << port << endl;

    //获取 DBInfo
    const char *pDBInfo = p_config->GetString("DBInfo");
    if (pDBInfo != NULL)
    {
        cout << "DBInfo =  " << pDBInfo << endl;
    }
    
    ngx_setproctitle("nginx: master process");

    // printf("argc=%d,argv[0]=%s\n",argc,argv[0]);
    // strcpy(argv[0],"ce");
    // strcpy(argv[0],"c2212212121322324323e");
    // printf("===========================\n");    
    // printf("evriron[0]=%s\n" , environ[0]);  //environ[]系统提供的全局数组
    // printf("evriron[1]=%s\n" , environ[1]);
    // printf("evriron[2]=%s\n" , environ[2]);
    // printf("evriron[3]=%s\n" , environ[3]);
    // printf("evriron[4]=%s\n" , environ[4]);

    for(;;)
    {
        sleep(1); //休息1秒
        printf("休息1秒\n");
    }

    //对于因为设置可执行程序标题导致的环境变量分配的内存，需要释放 ngx_init_setproctitle 中 new 出来的
    if(gp_envmem)
    {
        delete []gp_envmem;
        gp_envmem = NULL;
    }

    return 0;
}