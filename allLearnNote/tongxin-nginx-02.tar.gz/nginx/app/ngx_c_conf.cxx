﻿#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ngx_c_conf.h"
#include "ngx_global.h"
#include "ngx_func.h"

using namespace std;

//静态成员初始化
CConfig* CConfig::m_instance = NULL;

CConfig::CConfig() {
	cout << "构造函数" << endl;
}
CConfig::~CConfig() {
	cout << "析构函数" << endl;
	//释放掉 new 出来的 m_ConfigItemList 每个元素
	vector<LPCConfItem>::iterator pos = m_ConfigItemList.begin();
	for(; pos != m_ConfigItemList.end();++pos) 
	{
		delete(*pos);
	}
	//释放掉之后数组就是空的了
}

// --------------------- 下面实现一些功能函数 --------------------------
// 加载配置文件函数
bool CConfig::Load(const char * pconfName)  // 传入的是配置文件的文件名
{
	FILE *fp;
	fp = fopen(pconfName,"r");  //打开配置文件
	if(fp == NULL) {
		return false;
	}

    //读取配置文件中的一行
    char linebuf[501];
    
    // feof 检查文件是否结束，函数 feof 只用于检测流文件
    while (!feof(fp))
    {
        // C 库函数 char *fgets(char *str, int n, FILE *stream) 
		// 从指定的流 stream 读取一行，并把它存储在 str 所指向的字符串内。
		// 当读取 (n-1) 个字符时，或者读取到换行符时，或者到达文件末尾时，它会停止，具体视情况而定。
		if( fgets(linebuf, 500 ,fp)  == NULL) {  //返回的是第一个字符的指针，如果这行为空就直接跳过
			continue;
		}

		// 处理注释行,如果开头以这些字符开始，就pass掉
		if(*linebuf==';' || *linebuf==' ' || *linebuf=='#' || *linebuf=='\t'|| *linebuf=='\n')
			continue;

	//循环读取
	lblprocstring:
		//如果最后是换行，回车，空格等都要截取掉
		size_t len = strlen(linebuf);	 //strlen 不包括 “/n” ,sizeof 包括
		if(len > 0) //如果这一行有数据  
		{
			//最后一个字符
			if( linebuf[len - 1] == 10 || linebuf[len  -1] == 13 || linebuf[len - 1] == 32 ) 
			{
				linebuf[len - 1] = 0;
				goto lblprocstring;  //继续判断倒数第二
			}
		}
		//开头也要处理
		//如果这一行开头是空格，就不要管
		if(linebuf[0] == 0)
			continue;
		//[开头的也不处理
		if(*linebuf == '[')
			continue;
		
		// 走下来的都这种格式 “ListenPort = 5678”
		//出去等号的位置,返回指针
		char *ptmp = strchr(linebuf,'=');  //strchr() 寻找 = 第一次出现的位置
		if(ptmp != NULL) {
			//LPCConfItem 配置文件结构题，item , vlaue
			//LPCConfItem 是个结构指针 CConfItem 是结构类型
			LPCConfItem p_confitem = new CConfItem;
			//初始化
			// void *memset(void *str, int c, size_t n) 
			//复制字符 c（一个无符号字符）到参数 str 所指向的字符串的前 n 个字符。
			memset(p_confitem,0,sizeof(CConfItem));  

			 //等号左侧的拷贝到p_confitem->ItemName
			strncpy(p_confitem->ItemName,linebuf,(int)(ptmp - linebuf));
			//复制等号后面的
			strcpy( p_confitem->ItemContent,ptmp +1 );

			//去掉右边的空格
			Rtrim(p_confitem->ItemName);
			//去掉左边的空格
			Ltrim(p_confitem->ItemName);
			Rtrim(p_confitem->ItemContent);
			Ltrim(p_confitem->ItemContent);

			//把配置文件的每一项 存在数组中
			m_ConfigItemList.push_back(p_confitem);
			//p_confitem 内存要释放，因为这里是new出来的 在析构函数
		}
    }
	fclose(fp);
	return true;
}

// 根据ItemName获取配置信息字符串
const char *CConfig::GetString(const char *p_itemname)
{
	vector<LPCConfItem>::iterator pos = m_ConfigItemList.begin();
	for(; pos!= m_ConfigItemList.end();++pos) {
		// strcasecmp()函数：判断字符串是否相等(忽略大小写)
		if(strcasecmp( (*pos)->ItemName,p_itemname ) == 0) //如果相等
		{
			return (*pos)->ItemContent;
		}
	}
	return NULL;
}

//根据ItemName获取数字类型配置信息
int CConfig::GetIntDefault(const char *p_itemname,const int def)
{
	vector<LPCConfItem>::iterator pos = m_ConfigItemList.begin();
	for(; pos != m_ConfigItemList.end();++pos) {
		if( strcasecmp((*pos)->ItemName,p_itemname) == 0) {
			return atoi( (*pos)->ItemContent );  //将字符串转成 int 类型返回
		}
	}
	return def;
}